import { supabase } from "@/lib/supabaseClient"
import { getAnonymousUserId } from "@/utils/user"

export interface FeedbackData {
  metrics: Record<string, number>
  suggestions: string[]
  issues: string[]
}

export async function submitFeedbackToSupabase(feedback: FeedbackData): Promise<void> {
  const userId = getAnonymousUserId()
  const environment = import.meta.env.MODE === "development" ? "dev" : "prod"

  const { error } = await supabase.from("feedback").insert([
    {
      user_id: userId,
      environment,
      metrics: feedback.metrics,
      suggestions: feedback.suggestions,
      issues: feedback.issues,
    },
  ])

  if (error) {
    console.error("❌ Error submitting feedback to Supabase:", error)
  } else {
    console.log("✅ Feedback successfully submitted to Supabase.")
  }
}
